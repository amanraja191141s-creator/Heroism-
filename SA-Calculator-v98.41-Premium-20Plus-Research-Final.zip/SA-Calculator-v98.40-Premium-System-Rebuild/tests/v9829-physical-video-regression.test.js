const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.29 release identity and service-worker cache are bumped together', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version, '1.98.41-v98.41');
  assert.equal(manifest.version, pkg.version);
  assert.match(read('index.html'), /sa-build-version" content="1\.98\.41-v98\.41/);
  assert.match(read('assets/js/app.js'), /APP_VERSION = '1\.98\.41-v98\.41'/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-41-premium-ui-audit/);
});

test('tool screens use only the real toolbar, not legacy pseudo title bars', () => {
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(css, /#screen-viewport > \.screen:not\(#screen-calc\)::before,[\s\S]*?content:none !important; display:none !important;/);
  assert.match(css, /header\.app-header::before, header\.app-header::after \{ content:none !important; display:none !important; \}/);
  assert.match(read('assets/js/app.js'), /className = 'reference-screen-toolbar'/);
});

test('Fuel Cost has a manual Calculate action and explicit empty-state result', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(html, /id="fc-calculate"[^>]*>Calculate<\/button>/);
  assert.match(html, /id="fuel-cost-result" data-state="empty"/);
  assert.match(js, /getElementById\('fc-calculate'\)\?\.addEventListener\('click', calcFuelCost\)/);
  assert.match(js, /setState\('empty',/);
  assert.match(js, /setState\('incomplete',/);
  assert.match(js, /setState\('success'\)/);
  assert.match(css, /#screen-fuelcost #fuel-cost-result\[data-state="empty"\]/);
});

test('Body Metrics empty status cannot render as an empty white pill', () => {
  const html = read('index.html');
  const css = read('assets/css/rebuild-v98.32.css');
  const js = read('assets/js/app.js');
  assert.match(html, /id="body-metric-result" data-state="empty"/);
  assert.match(css, /#screen-bodymetrics #bmi-status:empty \{ display:none !important/);
  assert.match(js, /resultCard\.dataset\.state = hasAny \? 'incomplete' : 'empty'/);
});

test('Loan suffixes stay in the input track and amortization table can scroll horizontally', () => {
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(css, /#screen-loan \.reference-input-suffix \.input-val-box \{ flex:1 1 0 !important; width:1% !important; min-width:0/);
  assert.match(css, /#screen-loan \.loan-table-wrap \{ overflow-x:auto !important/);
});

test('Unit Price winner label matches the visible item heading rather than internal key', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /const heading=document\.getElementById\(rowId\)\?\.previousElementSibling/);
  assert.match(js, /winners\[0\]\.label\} \(Lowest unit price\)/);
});

test('all three Android workflows agree on v98.29 identity and cache namespace', () => {
  const a = read('.github/workflows/main.yml');
  const b = read('android-apk.yml');
  const c = read('main-v98.32-authoritative-rebuild.yml');
  assert.equal(a, b);
  assert.equal(b, c);
  assert.match(a, /SA_EXPECTED_VERSION: '1\.98\.41-v98\.41'/);
  assert.match(a, /versionCode='1098041'/);
  assert.match(a, /sa-calculator-v98-41-premium-ui-audit/);
});

test('Currency picker search is visible on open and its header search action focuses the field', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(html, /id="cur-from"/);
  assert.match(js, /const searchableCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /sumaire-picker-search-wrap/);
  assert.match(css, /\.sumaire-picker-search-wrap:not\(\[hidden\]\)/);
});

test('Calculator home header keeps the SA Calculator brand title visible', () => {
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(css, /header\.app-header #app-title \{ display:block !important; visibility:visible !important/);
});
