# SA Calculator v98.40 — Android screenshot corrections

## Screenshot defects addressed
- The clipped blue top outline was traced to the fixed skip-to-workspace link retaining touch focus in Android WebView. The link is visually hidden by default and is revealed only during keyboard navigation; pointer interaction clears keyboard modality and blurs a touch-focused skip link.
- The calculator expression/result display card boundary is removed at the actual `#calc-display-box` element and its expression/result descendants, including pseudo-elements, outlines and shadows.
- The calculator display height is reduced so the keypad receives the released vertical space. Keypad rows remain five equal grid tracks and are allowed to shrink on short viewports.
- Bottom navigation tabs are constrained to a compact fixed height; Android safe-area space remains painted with the navigation background instead of stretching the tab hit surfaces.
- Currency and Unit Converter utility keys display icons only (backspace, switch field, clear, confirm); accessible labels remain available to TalkBack.

## Compatibility
- Existing calculation functions, all 18 existing screen IDs, converter input routing, currency rate logic, scientific modal/engine, preferences, history, themes and navigation remain intact.
- The existing scientific calculator menu entry is retained and its quick-action label is made explicit; no duplicate calculation engine is introduced.
- v98.40 stylesheet is linked, required by Android bundle preparation and precached under a new service-worker cache identity.
