# SA Calculator v98.40 — Android screenshot correction release

This release is based on the supplied Android screenshot and the actual v98.39 source archive.

## Screenshot-led fixes in v98.40

- Removes the blue top skip-link outline that Android WebView could leave visible after touch focus. Keyboard navigation still reveals the skip link; pointer interaction resets the modality state.
- Removes the expression/result display card boundary and decorative frame while keeping both expression editing and live/committed results.
- Reduces the calculator display height so the five-row keypad receives the released space.
- Removes the duplicate CSS bottom safe-area spacer because the native Android `MainActivity` already applies system-bar insets. Bottom navigation tabs now keep a compact fixed height instead of stretching into the lower blank region.
- Changes Currency and Unit Converter keypad utility labels to compact icons (backspace, switch field, clear, confirm) while retaining TalkBack accessible names.
- Keeps Scientific Calculator discoverable in the tool drawer and uses the existing tested scientific engine rather than introducing a duplicate engine.

## Preserved systems

All 18 existing screen IDs, calculation handlers, scientific DEG/RAD functions, converter routing, currency rate providers/cache, preferences, history, favorites, localization, themes and Android branding/build logic are retained.

## Development and validation

```bash
npm install
npm test
npm run build:web
```

The v98.40 regression suite contains 286 passing tests. JavaScript syntax, YAML parsing, release identity synchronization, offline asset precache and Android web-bundle generation are validated.

## Android APK and device testing

Use `SA-Calculator-v98.40-Android-Workflow.yml` in GitHub Actions or `.github/workflows/main.yml`. The workflow validates the exact v98.40 source, runs the test suite, builds the web bundle, synchronizes Capacitor, applies Android branding/insets and builds a debug APK.

A hosted APK build and installation on the target phone have not yet been performed in this session. Therefore device-specific visual rendering, touch behavior, FPS/jank, memory, battery and ANR testing remain pending; no claim of universal zero-lag or bug-free behavior is made before those tests.
